<h1><?php echo ucfirst($this->shared_data->get('title')); ?></h1>
<?php $this->yieldView(); ?>
<div>footer</div>
