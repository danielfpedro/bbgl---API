My name is <?php echo ucwords($this->shared_data->get('name')); ?>.
<?php echo strtoupper($this->shared_data->get('verb')); ?>!
